<table>
    <thead>
        <tr>
            <th>#</th>
            <th>Name</th>
            <th>Mobile</th>
            <th>Email</th>
            <th>Gender</th>
            <th>Is_Married</th>
            <th>Status</th>

            <th>Created At</th>
            <th>Updated At</th>

        </tr>
    </thead>
    <tbody>
        <tr></tr>
        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($customer->id); ?></td>
            <td><?php echo e($customer->name); ?></td>
            <td><?php echo e($customer->mobile); ?></td>
            <td><?php echo e($customer->email); ?></td>
            <td><?php echo e($customer->gender); ?></td>
            <td><?php echo e($customer->is_married); ?></td>
            <td><?php echo e($customer->status); ?></td>
            <td><?php echo e($customer->created_at); ?></td>
            <td><?php echo e($customer->updated_at); ?></td>


        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH D:\interviews\crud\resources\views/customers/excel/export.blade.php ENDPATH**/ ?>